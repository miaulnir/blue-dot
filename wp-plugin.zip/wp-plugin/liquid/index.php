<?php
header("Location:install");
?>